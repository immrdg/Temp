package org.example.railwaycrossingapp.servlets.admin.ops;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.hibernate.Session;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/admin/DisplayById")
public class DisplayById extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter respWriter = resp.getWriter();
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
            System.out.println(req.getParameter("id"));
            CrossingInfo crossingInfo = session.find(CrossingInfo.class, req.getParameter("id"));
            if(crossingInfo==null) {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                respWriter.println("No crossing info found with id " + req.getParameter("id"));
            }
            else {
                resp.setContentType("application/json");
                respWriter.write(new ObjectMapper().writeValueAsString(crossingInfo));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error getting from DisplayById: " + e.getMessage());
        }
    }
}
