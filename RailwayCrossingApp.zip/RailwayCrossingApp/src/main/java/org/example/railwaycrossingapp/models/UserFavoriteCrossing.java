package org.example.railwaycrossingapp.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user_favorite_crossings")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserFavoriteCrossing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "crossing_id")
    private CrossingInfo crossing;

}
