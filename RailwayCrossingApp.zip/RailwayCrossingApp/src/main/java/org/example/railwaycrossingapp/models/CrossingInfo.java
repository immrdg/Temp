package org.example.railwaycrossingapp.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.example.railwaycrossingapp.converters.TimeConverter;

import java.sql.Time;
import java.util.List;

@Builder
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CrossingInfo {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;

    @Column(unique = true)
    private String name;

    @Enumerated(value = EnumType.STRING)
    private Status status;

    private String personInCharge;

    @Convert(converter = TimeConverter.class)
    private String time;

    private String landmark;

    private String address;

    @JsonIgnore
    @OneToMany(mappedBy = "crossing", cascade = CascadeType.REMOVE)
    private List<UserFavoriteCrossing> favoriteCrossings;

}
