package org.example.railwaycrossingapp.servlets;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.example.railwaycrossingapp.models.Status;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.io.*;
import java.util.List;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String message;
    private static  int counter=1;

    public void init() {
        message = "Hello World! V3";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        SessionFactory sessionFactory = HibernateUtils.getSessionFactory();

        try(Session session = sessionFactory.openSession()){
            Transaction tx = session.getTransaction();
            tx.begin();


            CrossingInfo crossingInfo = new CrossingInfo();
            crossingInfo.setName("Sample Crossing");
            crossingInfo.setStatus(Status.OPEN);
            crossingInfo.setTime("10:30 am");
            crossingInfo.setLandmark("Sample Landmark");
            crossingInfo.setAddress("123 Main Street");

            session.persist(crossingInfo);
            tx.commit();
            List<CrossingInfo> crossings = session.createQuery("FROM CrossingInfo c order by c.id",CrossingInfo.class).list();
            response.getWriter().println(crossings);
        }catch (Exception e){
            response.getWriter().println(e.getMessage());
            System.err.println(e.getMessage());
        }


    }

}