package org.example.railwaycrossingapp.listeners;

import org.example.railwaycrossingapp.config.HibernateUtils;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class SessionFactoryClose implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println(HibernateUtils.getSessionFactory()!=null);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Context destroyed ");
        HibernateUtils.getSessionFactory().close();
    }
}
