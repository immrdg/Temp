package org.example.railwaycrossingapp.config;

import lombok.Getter;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtils {
    @Getter
    private static SessionFactory sessionFactory = null;

    static {
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure().build();
        sessionFactory = new MetadataSources(ssr).buildMetadata().buildSessionFactory();
    }

}
