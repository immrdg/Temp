package org.example.railwaycrossingapp.filters;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/admin/*") // Specify the URL pattern to filter
public class AdminFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        HttpSession session = httpRequest.getSession(false);
        if(session!=null)
            session.getAttributeNames().asIterator().forEachRemaining(System.out::println);

        // Check if the user is logged in and has admin privileges
        if (session != null && session.getAttribute("isAdmin") != null && (Boolean) session.getAttribute("isAdmin")) {
            // User has admin privileges, proceed with the request
            chain.doFilter(request, response);
        } else {
            // Redirect to a login page or show an access denied page
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
        }
    }

    // Other methods from the Filter interface (init, destroy) can be left empty
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
}
