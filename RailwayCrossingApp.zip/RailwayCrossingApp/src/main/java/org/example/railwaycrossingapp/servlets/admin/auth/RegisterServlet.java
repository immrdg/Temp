package org.example.railwaycrossingapp.servlets.admin.auth;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.User;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/signup")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd=req.getRequestDispatcher("signup.jsp");
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try(Session session= HibernateUtils.getSessionFactory().openSession()){
            Transaction tx=session.getTransaction();
            tx.begin();

            User user = User.builder().username(req.getParameter("username")).
                    password(req.getParameter("password")).
                    name(req.getParameter("name")).
                    isAdmin(Boolean.FALSE).build();
            session.persist(user);
            tx.commit();

            resp.sendRedirect(req.getContextPath()+"/login");
        }catch (ConstraintViolationException e) {
            resp.sendRedirect(req.getServletContext()+"/signup?error=UserNameAlreadyExists");
        }
    }
}
