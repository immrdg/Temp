package org.example.railwaycrossingapp.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    @Column(nullable = false)
    private String username;

    private String password;

    @JsonIgnore
    @Column(columnDefinition = "boolean DEFAULT FALSE")
    private Boolean isAdmin;

    @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE)
    private List<UserFavoriteCrossing> userFavoriteCrossings;

}
