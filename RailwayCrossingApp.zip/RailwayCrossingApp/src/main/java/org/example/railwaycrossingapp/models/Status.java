package org.example.railwaycrossingapp.models;

import lombok.Getter;

@Getter
public enum Status {
    OPEN("OPEN"),CLOSE("CLOSE");
    private final String status;

    Status(String status) {
        this.status = status;
    }
}
