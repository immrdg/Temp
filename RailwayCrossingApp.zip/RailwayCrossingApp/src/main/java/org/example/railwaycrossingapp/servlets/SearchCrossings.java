package org.example.railwaycrossingapp.servlets;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.hibernate.Session;
import org.hibernate.query.Query;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/SearchCrossings")
public class SearchCrossings extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String query = req.getParameter("searchQuery");

        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            List<CrossingInfo> myCrossings;

            if (query == null || query.isEmpty()) {
                myCrossings = new ArrayList<>();
            } else {
                Query<CrossingInfo> query1 = session.createQuery(
                        "select c from CrossingInfo c where c.name like :name", CrossingInfo.class);
                query1.setParameter("name", "%" + query + "%");

                myCrossings = query1.list();
                System.out.println(myCrossings);
            }

            req.setAttribute("crossings", myCrossings);
            req.setAttribute("count", myCrossings.size());

            HttpSession session1 = req.getSession(false);
            Integer userId = null;
            if (session1 != null) {
                userId = (Integer) session1.getAttribute("user");
            }

            if (userId != null) {
                List<Integer> favIds = session.createQuery(
                                "select u.crossing.id from UserFavoriteCrossing u where u.user.id = :userId", Integer.class)
                        .setParameter("userId", userId)
                        .list();
                req.setAttribute("favs", favIds);
            }

            RequestDispatcher requestDispatcher = req.getRequestDispatcher("searchCrossings.jsp");
            requestDispatcher.forward(req, resp);
        }
    }
}
