package org.example.railwaycrossingapp.servlets.admin.auth;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.User;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
        rd.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
             //Use a query to check if the user with the provided credentials exists
            Query<User> query = session.createQuery("from User u where u.username=:username and u.password=:password", User.class);
            query.setParameter("username", username);
            query.setParameter("password", password);

            User user = query.uniqueResult();

            System.out.println("User with username"+user);


            if (user != null) {
                // Authentication successful, set user information in the session
                HttpSession httpSession = req.getSession();
                httpSession.setAttribute("user", user.getId());
                httpSession.setAttribute("isAdmin", user.getIsAdmin());

                System.out.println("-->");
                httpSession.getAttributeNames().asIterator().forEachRemaining(System.out::println);
                System.out.println("<--");
                // Redirect to a home page or dashboard
                resp.sendRedirect(req.getContextPath() + "/home");
            } else {
                // Authentication failed, redirect back to login page with an error message
                req.setAttribute("error", "Invalid username or password");
                RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
                rd.forward(req, resp);
            }
        }
    }
}