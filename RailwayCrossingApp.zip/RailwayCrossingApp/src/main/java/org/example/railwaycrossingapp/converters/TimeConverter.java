package org.example.railwaycrossingapp.converters;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Converter(autoApply = true)
public class TimeConverter implements AttributeConverter<String, Time> {

    private final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
    @Override
    public Time convertToDatabaseColumn(String attribute) {
        try {
            if (attribute != null) {
                return new Time(timeFormat.parse(attribute).getTime());
            }
        } catch (ParseException e) {
            // Handle parsing exception
            System.err.println(e.getMessage());
        }
        return null;
    }

    @Override
    public String convertToEntityAttribute(Time dbData) {
        if (dbData != null) {
            return timeFormat.format(dbData);
        }
        return null;
    }
}
