package org.example.railwaycrossingapp.servlets.wishlist;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.hibernate.Session;
import org.hibernate.query.Query;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/my-wishlist")
public class MyWishListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession h_session = req.getSession(false);
        if(h_session==null || h_session.getAttribute("user")==null){
            resp.sendRedirect(req.getContextPath()+"/login");
            return;
        }
        try(Session session= HibernateUtils.getSessionFactory().openSession()) {

            Query<CrossingInfo> query = session.createQuery("select u.crossing from UserFavoriteCrossing u where u.user.id=:uid",CrossingInfo.class);
            query.setParameter("uid",h_session.getAttribute("user"));

            List<CrossingInfo> crossings = query.list();

            RequestDispatcher requestDispatcher = req.getRequestDispatcher("wishlist.jsp");
            req.setAttribute("crossings",crossings);

            requestDispatcher.forward(req,resp);
        }

    }
}
