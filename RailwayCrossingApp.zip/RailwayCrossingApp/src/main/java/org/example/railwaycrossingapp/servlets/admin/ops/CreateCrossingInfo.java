package org.example.railwaycrossingapp.servlets.admin.ops;


import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.example.railwaycrossingapp.models.Status;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/admin/ops/create")
public class CreateCrossingInfo extends HttpServlet {

    SimpleDateFormat inputFormat = new SimpleDateFormat("HH:mm");
    SimpleDateFormat outputFormat = new SimpleDateFormat("hh:mm a");


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher dispatcher = req.getRequestDispatcher("createCrossingInfo.jsp");
        dispatcher.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("CreateCrossingInfo");

        String time = req.getParameter("time");
        System.out.println(time);
        try {
            Time date = new Time(inputFormat.parse(time).getTime());
            time = outputFormat.format(date);
            System.out.println(time);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        try(Session session= HibernateUtils.getSessionFactory().openSession()) {

            Transaction tx = session.getTransaction();
            tx.begin();
                CrossingInfo newCrossingInfo = CrossingInfo.
                        builder().
                        name(req.getParameter("name")).
                        status(Status.valueOf(req.getParameter("status"))).
                        personInCharge(req.getParameter("personInCharge")).
                        landmark(req.getParameter("landmark")).
                        address(req.getParameter("address")).
                        time(time).
                        build();
            System.err.println("nEW iNFO"+newCrossingInfo);

                session.persist(newCrossingInfo);

                tx.commit();
            System.out.println(newCrossingInfo);

            resp.sendRedirect(req.getContextPath() + "/admin/home");
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
