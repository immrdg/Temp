package org.example.railwaycrossingapp.servlets.admin.ops;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/DeleteCrossing")
public class DeleteCrossingServlet extends HttpServlet {

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("DeleteCrossing");
        String crossingId = request.getParameter("crossingId");
        System.out.println(crossingId);
        // Validate crossingId (you may want to perform additional validation)
        if (crossingId != null && !crossingId.isEmpty()) {
            try (Session session = HibernateUtils.getSessionFactory().openSession()) {
                // Assuming you have a Crossing entity mapped with an "id" attribute
                int id = Integer.parseInt(crossingId);
                CrossingInfo crossing = session.get(CrossingInfo.class, id);

                if (crossing != null) {
                    // Perform the deletion
                    Transaction transaction = session.beginTransaction();
                    session.remove(crossing);
                    transaction.commit();
                    response.setStatus(HttpServletResponse.SC_OK);
                } else {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

            }
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }
}
