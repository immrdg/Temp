package org.example.railwaycrossingapp.servlets.admin.ops;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.example.railwaycrossingapp.models.Status;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/admin/UpdateCrossingServlet")
public class UpdateCrossingServlet extends HttpServlet {

    SimpleDateFormat inputFormat = new SimpleDateFormat("HH:mm");
    SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ss");

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Retrieve parameters from the request
        System.out.println("Request UPDATE");
        String crossingId = req.getParameter("id");
        System.out.println(crossingId);
        String name = req.getParameter("name");
        String status = req.getParameter("status");
        String personInCharge = req.getParameter("personInCharge");
        String time = req.getParameter("time");
        try {
            Time date = new Time(inputFormat.parse(time).getTime());
            time = outputFormat.format(date);
            System.out.println(time);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String landmark = req.getParameter("landmark");
        String address = req.getParameter("address");

        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            Transaction transaction = session.getTransaction();
            transaction.begin();

            // Use native query to update CrossingInfo
            NativeQuery updateQuery = session.createNativeQuery("UPDATE CrossingInfo " +
                    "SET name = :name, status = :status, personInCharge = :personInCharge, " +
                    "time = :time, landmark = :landmark, address = :address " +
                    "WHERE id = :crossingId");

            updateQuery.setParameter("name", name);
            updateQuery.setParameter("status", status);
            updateQuery.setParameter("personInCharge", personInCharge);
            updateQuery.setParameter("time", time);
            updateQuery.setParameter("landmark", landmark);
            updateQuery.setParameter("address", address);
            updateQuery.setParameter("crossingId", Integer.parseInt(crossingId));
            updateQuery.executeUpdate();


            transaction.commit();

            System.out.println("Done");
            resp.setStatus(HttpServletResponse.SC_OK);
            resp.setContentType("application/text");
            resp.getWriter().write("Crossing updated successfully");
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
        }
    }
}