package org.example.railwaycrossingapp.servlets.admin;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.hibernate.Session;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/home")
public class AdminHome extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)  {

        try(Session session= HibernateUtils.getSessionFactory().openSession()) {
            List<CrossingInfo> crossingInfos=session.createQuery("FROM CrossingInfo",CrossingInfo.class).list();
            req.setAttribute("crossings",crossingInfos);
            req.setAttribute("crossingCount",crossingInfos.size());
            RequestDispatcher rd = req.getRequestDispatcher("adminHome.jsp");
            rd.forward(req,resp);
        }catch (Exception e){
            System.err.println(e.getMessage());
        }
    }
}
