package org.example.railwaycrossingapp.servlets.wishlist;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.example.railwaycrossingapp.models.User;
import org.example.railwaycrossingapp.models.UserFavoriteCrossing;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/DeleteFavorite")
public class DeleteFavourite extends HttpServlet {

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String user_id = req.getParameter("userId");
        String crossing_id = req.getParameter("crossingId");

        System.out.println("User: " + user_id);
        System.out.println("Crossing: " + crossing_id);
        int u=0;
        try(Session session = HibernateUtils.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            User user = session.get(User.class, Integer.parseInt(user_id));
            CrossingInfo crossingInfo = session.get(CrossingInfo.class, Integer.parseInt(crossing_id));
            if (user != null && crossingInfo != null) {
                UserFavoriteCrossing favorite = user.getUserFavoriteCrossings().stream()
                        .filter(f -> f.getCrossing().getId() == Integer.parseInt(crossing_id))
                        .findFirst()
                        .orElse(null);

                if (favorite != null) {
                    // Remove the crossing from user's favorites
                    user.getUserFavoriteCrossings().remove(favorite);
                    session.remove(favorite);

                    resp.getWriter().write("{\"success\": true}");
                }
            }
            tx.commit();
            resp.setContentType("application/text");
            resp.getWriter().write(u + " rows Deleted successfully");
        }catch (Exception e) {
            e.printStackTrace();
        }

    }
}
