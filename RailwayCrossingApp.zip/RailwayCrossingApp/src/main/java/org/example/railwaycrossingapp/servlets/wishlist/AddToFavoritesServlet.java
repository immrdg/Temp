package org.example.railwaycrossingapp.servlets.wishlist;

import org.example.railwaycrossingapp.config.HibernateUtils;
import org.example.railwaycrossingapp.models.CrossingInfo;
import org.example.railwaycrossingapp.models.User;
import org.example.railwaycrossingapp.models.UserFavoriteCrossing;
import org.hibernate.Session;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/AddToFavorites")
public class AddToFavoritesServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userId=req.getParameter("userId");
        String crossingId=req.getParameter("crossingId");

        try(Session session= HibernateUtils.getSessionFactory().openSession()) {
            User user=session.get(User.class,Integer.parseInt(userId));
            CrossingInfo crossingInfo=session.get(CrossingInfo.class,Integer.parseInt(crossingId));

            if (user != null && crossingInfo != null) {
                // Check if the crossing is already in the user's favorites
                boolean isAlreadyFavorite =  user.getUserFavoriteCrossings()
                        .stream()
                        .anyMatch(favorite -> favorite.getCrossing().getId() == Integer.parseInt(crossingId));

                if (!isAlreadyFavorite) {
                    // Add the crossing to user's favorites
                    UserFavoriteCrossing userFavoriteCrossing = new UserFavoriteCrossing();
                    userFavoriteCrossing.setUser(user);
                    userFavoriteCrossing.setCrossing(crossingInfo);

                    // Update the database
                    session.beginTransaction();
                    session.persist(userFavoriteCrossing);
                    session.getTransaction().commit();

                    resp.getWriter().println("{\"success\": true}");
                }
            }
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
