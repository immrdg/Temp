import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;



public class TransformPegaInput implements Callable {
	
	private String getCharForNumber(int i) {
	    return i > 0 && i < 27 ? String.valueOf((char)(i + 'A' - 1)) : null;
	}
	
	private void getFilters(List<Map<String,Object>> params,Map<String,Object> result)
	{
		
		List<Map<String,Object>> filterArray = new ArrayList();

		for(Map<String,Object> paramList : params)
	    {
	    	Map<String,Object> tempList = new HashMap();
	    	for (Map.Entry<String, Object> entry : paramList.entrySet())
	    	{
	    		if(entry.getValue().equals("Order By") || entry.getValue().equals("Offset") || entry.getKey().equals("Values") || entry.getKey().equals("NotValues") || entry.getValue().equals("Between"))
	    		{	
	    			//System.out.println("Yo");
	    		}
	    		else
	    		{
	    			tempList.putAll(paramList);
	    			tempList.put("Subscript", getCharForNumber(params.indexOf(paramList)+1));
	    			filterArray.add(tempList);
	    		}
	    	}	
	    }
	    System.out.println(filterArray);
	    result.put("Filters", filterArray);
	}
	
	private void getSorting(List<Map<String,Object>> params,Map<String,Object> result)
	{
		Map<String,List<Map<String,Object>>> sorting = new HashMap();
	    List<Map<String,Object>> sortArray = new ArrayList();
	    
	    for(Map<String,Object> paramList : params)
	    {
	    	for (Map.Entry<String, Object> entry : paramList.entrySet())
	    	{
	    		if(entry.getValue().equals("Order By"))
	    		{	
	    			ArrayList orderVal = (ArrayList) paramList.get("Values");
	    			for(Object vals: orderVal)
	    			{
	    				Map<String,Object> tempMap = new HashMap();	
	    				String[] splitStr = vals.toString().trim().split("\\s+");
	    				tempMap.put("Name", splitStr[0]);
	    				tempMap.put("SortBy", StringUtils.capitalize(splitStr[1]));
	    				sortArray.add(tempMap);
	    			}
	    		}
	    		
	    	}
	    }
	    System.out.println(sortArray);
	    result.put("Sorting",sortArray);
	}
	
	private void getOffset(List<Map<String,Object>> params,Map<String,Object> result)
	{
		for(Map<String,Object> paramList : params)
	    {
	    	for (Map.Entry<String, Object> entry : paramList.entrySet())
	    	{
	    		if(entry.getValue().equals("Offset"))
	    		{	
	    			ArrayList offsetVal = (ArrayList) paramList.get("Values");
	    			for(Object val: offsetVal)
	    			{	
	    				int valint = Integer.parseInt(val.toString());
	    				result.put("Offset",valint);
	    			} 		
	    		}	    		
	    	}
	    }
	    
	}
	
	public void getFilterLogic(Map<String,Object> result)
	{
		result.put("FilterLogic","(A AND B)");
	}
	
	public Object onCall(MuleEventContext eventContext) throws Exception {
	    Object optyPayload = eventContext.getMessage().getPayload();
	    ObjectMapper oMapper = new ObjectMapper();
	    
	    
	    List<Map<String,Object>> params = new ArrayList();
	    Map<String,List<Map<String,Object>>> inputParam = oMapper.convertValue(optyPayload, Map.class);
	    params = inputParam.get("parameters");
	    
	    Map<String,Object> result = new HashMap();
		
	    
	    getSorting(params,result);
	    getFilters(params,result);
	    getOffset(params,result);
	    getFilterLogic(result);
	    return result;
	    
	}
	
	
	
	
}

