import java.util.List;

public class Parameter {
	String Name;
	List[] Values;
	String Subscript;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public List[] getValues() {
		return Values;
	}
	public void setValues(List[] values) {
		Values = values;
	}
	public String getSubscript() {
		return Subscript;
	}
	public void setSubscript(String subscript) {
		Subscript = subscript;
	}
	List NotValues[];
	public List[] getNotValues() {
		return NotValues;
	}
	public void setNotValues(List[] notValues) {
		NotValues = notValues;
	}
}
